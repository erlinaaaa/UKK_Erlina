import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class Peminjaman extends javax.swing.JFrame {
Connection konek = Koneksi.koneksiDB();
    /**
     * Creates new form Peminjaman
     */
    public Peminjaman() {
        initComponents();
        tampilDataPeminjaman();
    }

    private void tampilDataPeminjaman(){
          DefaultTableModel model = new DefaultTableModel();
          model.addColumn("PeminjamanID");
          model.addColumn("UserID");
          model.addColumn("BukuID");
          model.addColumn("Tanggal Peminjaman");
          model.addColumn("Tanggal Pengembalian");
          model.addColumn("Status Pengembalian");
          jTable1.setModel(model);
          
          try{
              Statement stat = konek.createStatement();
              ResultSet data = stat.executeQuery("SELECT * FROM peminajaman");
              while (data.next()) {
                  model.addRow(new Object[] {
                  data.getString("peminjamanid"),
                  data.getString("userid"),
                  data.getString("bukuid"),
                  data.getString("tgl_peminjaman"),
                  data.getString("tgl_pengembalian"),
                  data.getString("sts_peminjaman"),
              });
              jTable1.setModel(model);
              }
          } catch (Exception e) {
              System.err.println("Terjadi Kesalahan :" + e);
          }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jDateChooser3 = new com.toedter.calendar.JDateChooser();
        jDateChooser4 = new com.toedter.calendar.JDateChooser();
        jPanel4 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton5 = new javax.swing.JButton();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("APLIKASI PERPUSTAKAAN DIGITAL");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(169, 169, 169))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(153, 153, 255));

        jLabel2.setText("UserID");

        jLabel3.setText("BukuID");

        jLabel4.setText("Tanggal Peminjaman");

        jLabel5.setText("Tanggal Pengembalian");

        jLabel6.setText("Status Peminjaman");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih", "1011", "1013", "1011", "1015", "1015" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih", "553", "553", "551", "552", "555" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jButton1.setText("Save");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Update");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel7.setText("PeminjamanID");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jComboBox1, 0, 139, Short.MAX_VALUE)
                        .addComponent(jTextField8))
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jDateChooser3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(jDateChooser4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(63, 63, 63)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(34, 34, 34)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(20, 20, 20))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jDateChooser4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel5))
                            .addGap(8, 8, 8)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(3, 3, 3)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel6)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton1)
                                    .addComponent(jButton2)
                                    .addComponent(jButton3)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(jDateChooser3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(22, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(29, 29, 29))))
        );

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));

        jButton4.setText("Search");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "PeminjamanID", "UserID", "BukuID", "TanggalPeminjaman", "TanggalPengembalian", "StatusPeminjaman"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton5.setText("Buku>>");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addGap(23, 23, 23))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        Buku panggil= new Buku();
                 panggil.show();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        try {
        Statement stat = konek.createStatement();
        ResultSet data = stat.executeQuery("SELECT bukuid FROM buku WHERE " 
                + " bukuid ='" + jComboBox2.getSelectedItem() + "'");
                   }
    catch (Exception e)
    {
        System.err.println("Terjadi Kesalahan :" + e);
    }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        try {
        Statement stat = konek.createStatement();
        ResultSet data = stat.executeQuery("SELECT userid FROM useriduser WHERE " 
                + " userid ='" + jComboBox1.getSelectedItem() + "'");
                   }
    catch (Exception e)
    {
        System.err.println("Terjadi Kesalahan :" + e);
    }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        String a=jTextField4.getText();
        DefaultTableModel model = new DefaultTableModel();
          model.addColumn("PeminjamanID");
          model.addColumn("UserID");
           model.addColumn("BukuID");
            model.addColumn("Tanggal Peminjaman");
            model.addColumn("Tanggal Pengembalian");
            model.addColumn("Status Peminjaman");
          jTable1.setModel(model);
        try{
            Statement stat = konek.createStatement();
            ResultSet data = stat.executeQuery("SELECT peminjamanid, userid, bukuid, tgl_peminjaman, tgl_pengembalian, sts_peminjaman FROM peminajaman WHERE peminjamanid LIKE '%"
                    + a + "%' OR userid LIKE '%" + a + "%'OR bukuid LIKE '%" + a + "%'OR tgl_peminjaman LIKE '%" + a + "%'OR tgl_pengembalian LIKE '%" + a + "%'OR sts_peminjaman LIKE '%" + a + "%'");
            while (data.next()) {
                model.addRow(new Object[]{
                    data.getString("peminjamanid"),
                    data.getString("userid"),
                     data.getString("bukuid"),
                      data.getString("tgl_peminjaman"),
                      data.getString("tgl_pengembalian"),
                      data.getString("sts_peminjaman"),
                });
                jTable1.setModel(model);
            }
            jTextField4.setText("");
        }
        catch (Exception e)
        {
            System.err.println("Terjadi Kesalahan :" + e);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try 
        {
          Statement stat = konek.createStatement();
          ResultSet data = stat.executeQuery("SELECT * FROM peminajaman WHERE peminjamanid ='" + jTextField8.getText() + "'");
          
          if (data.next()){
              
          }
          else if (jTextField8.getText().equals("") || jComboBox1.getSelectedItem().equals("Pilih..") || jComboBox2.getSelectedItem().equals("Pilih..")
                  || jDateChooser3.getDate()== null || jDateChooser4.getDate()== null|| jTextField3.getText().equals(""))
          {
            JOptionPane.showMessageDialog(null, "Data Tidak Boleh Kosong!!!!", "PERHATIAN!!!!", JOptionPane.WARNING_MESSAGE);
          }
          else {
              SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
              String tgl_peminjaman = String.valueOf(fm.format(jDateChooser3.getDate()));
              String tgl_pengembalian = String.valueOf(fm.format(jDateChooser4.getDate()));
              
              
              String sql = "INSERT INTO peminajaman (peminjamanid, userid, bukuid, tgl_peminjaman, tgl_pengembalian, sts_peminjaman) VALUES('" + jTextField8.getText() + "'"
                      + ",'" + jComboBox1.getSelectedItem() + "'"
                      + ",'" + jComboBox2.getSelectedItem() + "'"
                      + ",'" + tgl_peminjaman + "'"
                      + ",'" + tgl_pengembalian + "'"
                      + ",'" + jTextField3.getText() + "')";
              stat.executeUpdate(sql);
              
              jTextField8.setText("");
              jComboBox1.setSelectedIndex(0);
              jComboBox2.setSelectedIndex(0);
              jDateChooser3.setDate(null);
              jDateChooser3.setDate(null);
              jTextField3.setText("");
              jTextField8.requestFocus();
              
              JOptionPane.showMessageDialog(null, "Data berhasil disimpan!!!", "SUKSES", JOptionPane.INFORMATION_MESSAGE);
              tampilDataPeminjaman();
          }
          stat.close();
        } catch (Exception e){
            System.err.println("Terjadi kesalahan : " + e);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        try {
            SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
            int baris=jTable1.getSelectedRow();
            
            if (baris != -1){
                jTextField8.setText(jTable1.getValueAt(baris, 0).toString());
                jComboBox1.setSelectedItem(jTable1.getValueAt(baris, 1).toString());
                jComboBox2.setSelectedItem(jTable1.getValueAt(baris, 2).toString());
                jDateChooser3.setDate(fm.parse(jTable1.getValueAt(baris, 3).toString()));
                jDateChooser4.setDate(fm.parse(jTable1.getValueAt(baris, 4).toString()));
                jTextField3.setText(jTable1.getValueAt(baris, 5).toString());
            }
            jTextField8.setEnabled(false);
            
        } catch (Exception e){
            System.err.println("Terjadi Kesalahan : " + e);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if(jTextField8.getText().equals("") || jComboBox1.getSelectedItem().equals("Pilih--")
             || jComboBox2.getSelectedItem().equals("Pilih--") || jDateChooser3.getDate()==null || jDateChooser4.getDate()==null 
              || jTextField3.getText().equals(""))
     {
         JOptionPane.showMessageDialog(null, "Silahkan pilih data yang akan di edit!!!", "PERHATIAN", JOptionPane.WARNING_MESSAGE);
     }
     else if((jDateChooser4.getDate().before(jDateChooser3.getDate()))==true)
     {
         JOptionPane.showMessageDialog(null, "Tanggal kembali harus lebih dari atau sama dengan"
               + "tanggal pinjam!!!", "PERHATIAN", JOptionPane.WARNING_MESSAGE);
     }
     else
     {
         int ok = JOptionPane.showConfirmDialog(null, "Apakah anda yakin ingin mengubah data ini?",
                 "Konfirmasi Dialog", JOptionPane.YES_NO_OPTION);
         if (ok == 0)
         {
             try
             {
                 SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
                 String TanggalPeminjaman = String.valueOf(fm.format(jDateChooser3.getDate()));
                 String TanggalPengembalian = String.valueOf(fm.format(jDateChooser4.getDate()));
                 
                 String sql ="UPDATE peminajaman SET userid = '"+jComboBox1.getSelectedItem()
                 +"', bukuid = '"+jComboBox2.getSelectedItem()
                 +"', tgl_peminjaman = '"+TanggalPeminjaman
                 +"', tgl_pengembalian = '"+TanggalPengembalian
                 +"', sts_peminjaman = '"+jTextField3.getText()        
                 +"' WHERE peminjamanid = '" + jTextField8.getText().trim() + "'";
                 
                 Statement stat = konek.createStatement();
                 stat.executeUpdate(sql);
                 JOptionPane.showMessageDialog(null, "Data berhasil diubah!!!", "Ubah Data", JOptionPane.INFORMATION_MESSAGE);
                 stat.close();
                 
                 jTextField8.setText("");
                 jComboBox1.setSelectedIndex(0);
                 jComboBox2.setSelectedIndex(0);
                 jDateChooser3.setDate(null);
                 jDateChooser4.setDate(null);
                 jTextField3.setText("");
                 jTextField8.enable(true);
                 jTextField8.requestFocus();
                 
                 tampilDataPeminjaman();     
             }
             catch (Exception e)
             {
               JOptionPane.showMessageDialog(null, "Perubahan data gagal"+e.getMessage());  
             }
         }
     }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int ok = JOptionPane.showConfirmDialog(null, "Apakah anda yakin ingin menghapus data ini?", "Konfirmasi Dialog", JOptionPane.YES_NO_OPTION);
        if (ok == 0)
        {
            String sql = "delete from peminajaman where peminjamanid = '" + jTextField8.getText().trim() + "'";
            try
            {
            Statement stat = Koneksi.koneksiDB().createStatement();
            stat.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!!!", "Hapus Data", JOptionPane.INFORMATION_MESSAGE);
            stat.close();
            jTextField8.setText("");
            jComboBox1.setSelectedIndex(0);
            jComboBox2.setSelectedIndex(0);
            jDateChooser3.setDate(null);
            jDateChooser4.setDate(null);
            jTextField3.setText("");
            jTextField8.enable(true);
            jTextField8.requestFocus();
            tampilDataPeminjaman();
            
            stat.close();
        }
        catch (SQLException exc)
        {
                System.err.println(sql);
                System.err.println("Error : " + exc);
        }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Peminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Peminjaman().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private com.toedter.calendar.JDateChooser jDateChooser3;
    private com.toedter.calendar.JDateChooser jDateChooser4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField8;
    // End of variables declaration//GEN-END:variables

    
}
