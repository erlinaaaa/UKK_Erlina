import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class Koneksi {

    static PreparedStatement prepareStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static Object koneksiDb() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

        Connection koneksi=null;
    
    public static Connection koneksiDB()
    {
        try{
            String url="jdbc:mysql://localhost/perpustakaan";
            String user="root";
            String pass="";
            Class.forName("com.mysql.jdbc.Driver");
            Connection koneksi=DriverManager.getConnection(url,user,pass);
            return koneksi;
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
}
